﻿namespace ContainersSimulator.Models
{
    public enum SimulationSize
    {
        Small,
        Medium,
        Large,
    }
}
