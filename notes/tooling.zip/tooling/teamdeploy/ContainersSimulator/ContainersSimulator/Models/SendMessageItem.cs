﻿using System;

namespace ContainersSimulator.Models
{
    public class SendMessageItem
    {
        public Uri MessageUri { get; set; }
    }
}
